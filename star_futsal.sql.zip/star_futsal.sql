-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2018 at 11:29 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `star_futsal`
--

-- --------------------------------------------------------

--
-- Table structure for table `lapangan`
--

CREATE TABLE `lapangan` (
  `KODE_LAPANGAN` varchar(3) NOT NULL,
  `JUDUL` varchar(16) NOT NULL,
  `TIPE` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lapangan`
--

INSERT INTO `lapangan` (`KODE_LAPANGAN`, `JUDUL`, `TIPE`) VALUES
('L01', 'Lapangan 1', 'Rumput Sintetis');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `KODE_BAYAR` varchar(9) NOT NULL,
  `TGL_BAYAR` datetime NOT NULL,
  `STATUS_BAYAR` varchar(10) NOT NULL,
  `TOTAL_DIBAYARKAN` int(11) NOT NULL,
  `KODE_PENYEWAAN` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`KODE_BAYAR`, `TGL_BAYAR`, `STATUS_BAYAR`, `TOTAL_DIBAYARKAN`, `KODE_PENYEWAAN`) VALUES
('B20170001', '2017-04-07 00:00:00', 'LUNAS', 300000, 'DS2017001'),
('B20180001', '2018-01-01 10:00:00', 'LUNAS', 400000, 'DS2017002');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `ID` varchar(5) NOT NULL,
  `NAMA` varchar(30) NOT NULL,
  `ALAMAT` varchar(100) NOT NULL,
  `KONTAK` varchar(14) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `USERNAME` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`ID`, `NAMA`, `ALAMAT`, `KONTAK`, `PASSWORD`, `USERNAME`) VALUES
('ADM01', 'Median', 'Cileunyi', '089765432432', 'mmediann', 'mmediann');

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE `sewa` (
  `KODE_PENYEWAAN` varchar(9) NOT NULL,
  `TOTAL_TAGIHAN` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sewa`
--

INSERT INTO `sewa` (`KODE_PENYEWAAN`, `TOTAL_TAGIHAN`) VALUES
('DS2017001', 300000),
('DS2017002', 400000);

-- --------------------------------------------------------

--
-- Table structure for table `sewa_detail`
--

CREATE TABLE `sewa_detail` (
  `KODE_SEWA` varchar(9) NOT NULL,
  `PENYEWA` varchar(30) NOT NULL,
  `TELP` varchar(14) NOT NULL,
  `TGL_SEWA` datetime NOT NULL,
  `TGL_MULAI` datetime NOT NULL,
  `TGL_SELESAI` datetime NOT NULL,
  `STATUS` varchar(10) NOT NULL,
  `KODE_PENYEWAAN` varchar(9) DEFAULT NULL,
  `KODE_TARIF` varchar(3) DEFAULT NULL,
  `KODE_LAPANGAN` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sewa_detail`
--

INSERT INTO `sewa_detail` (`KODE_SEWA`, `PENYEWA`, `TELP`, `TGL_SEWA`, `TGL_MULAI`, `TGL_SELESAI`, `STATUS`, `KODE_PENYEWAAN`, `KODE_TARIF`, `KODE_LAPANGAN`) VALUES
('SS2017001', 'Ahmad Suhdi', '089765432154', '2017-04-06 09:00:00', '2017-04-10 08:00:00', '2017-04-10 09:00:00', 'BOOKED', 'DS2017001', 'T01', 'L01'),
('SS2017002', 'Ahmad Suhdi', '089765432154', '2017-04-06 09:00:00', '2017-04-10 09:00:00', '2017-04-10 10:00:00', 'BOOKED', 'DS2017001', 'T01', 'L01'),
('SS2017003', 'Ahmad Suhdi', '089765432154', '2017-04-06 09:00:00', '2017-04-10 10:00:00', '2017-04-10 11:00:00', 'BOOKED', 'DS2017001', 'T01', 'L01'),
('SS2018001', 'Nurmala', '08977723222', '2018-01-01 10:00:00', '2018-01-08 11:00:00', '2018-01-08 12:00:00', 'BOOKED', 'DS2017002', 'T01', 'L01'),
('SS2018002', 'Nurmala', '08977723222', '2018-01-01 10:00:00', '2018-01-07 10:00:00', '2018-01-07 11:00:00', 'BOOKED', 'DS2017002', 'T01', 'L01'),
('SS2018003', 'Nurmala', '08977723222', '2018-01-01 10:00:00', '2018-01-08 12:00:00', '2018-01-08 13:00:00', 'BOOKED', 'DS2017002', 'T01', 'L01'),
('SS2018004', 'Nurmala', '08977723222', '2018-01-01 10:00:00', '2018-01-07 11:00:00', '2018-01-07 12:00:00', 'BOOKED', 'DS2017002', 'T01', 'L01');

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `KODE_TARIF` varchar(3) NOT NULL,
  `TARIF` varchar(10) NOT NULL,
  `HARGA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`KODE_TARIF`, `TARIF`, `HARGA`) VALUES
('T01', 'Reguler', 100000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD PRIMARY KEY (`KODE_LAPANGAN`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`KODE_BAYAR`),
  ADD KEY `FK_DILAKUKAN` (`KODE_PENYEWAAN`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sewa`
--
ALTER TABLE `sewa`
  ADD PRIMARY KEY (`KODE_PENYEWAAN`);

--
-- Indexes for table `sewa_detail`
--
ALTER TABLE `sewa_detail`
  ADD PRIMARY KEY (`KODE_SEWA`),
  ADD KEY `FK_DISEWAKAN` (`KODE_LAPANGAN`),
  ADD KEY `FK_MELAKUKAN` (`KODE_PENYEWAAN`),
  ADD KEY `FK_MENARIFKAN` (`KODE_TARIF`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`KODE_TARIF`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `FK_DILAKUKAN` FOREIGN KEY (`KODE_PENYEWAAN`) REFERENCES `sewa` (`KODE_PENYEWAAN`);

--
-- Constraints for table `sewa_detail`
--
ALTER TABLE `sewa_detail`
  ADD CONSTRAINT `FK_DISEWAKAN` FOREIGN KEY (`KODE_LAPANGAN`) REFERENCES `lapangan` (`KODE_LAPANGAN`),
  ADD CONSTRAINT `FK_MELAKUKAN` FOREIGN KEY (`KODE_PENYEWAAN`) REFERENCES `sewa` (`KODE_PENYEWAAN`),
  ADD CONSTRAINT `FK_MENARIFKAN` FOREIGN KEY (`KODE_TARIF`) REFERENCES `tarif` (`KODE_TARIF`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
